#include	<math.h>

/*
 * Main body of the run-time manipulator inverse dynamics function.
 * Requires 3 intermediate files produced by the MAPLE script genCcode.
 *
 * Copyright (c) 1996 Peter I. Corke
 */



rne(double *Tau, double *q, double *qd, double *qdd)
{
#include	"TEMP-DECL"
      double	S[N], C[N];
      int	i;


	for (i=0; i<N; i++)
		S[i] = sin(q[i]); C[i]= cos(q[i]);

#include	"TEMPS"
#include	"TORQUES"

}
