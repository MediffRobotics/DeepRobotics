'''Test quaternions and tranform primitives'''

from robot import *

tests = '''

# utility
v1 = mat([0, 1, 0]);
v2 = mat([0, 0, 1]);
unit(v1+v2)
crossp(v1, v2)
crossp(v1.T, v2)
crossp(v1, v2.T)
crossp(v1.T, v2.T)

m = mat(zeros( (3,4) ));
numcols(m)
numrows(m)

# transform primitives
rotx(.1)
roty(.1)
rotz(.1)

r = rotz(0.1)
r2t(r)


trotx(.1)
troty(.1)
trotz(.1)

t = trotz(0.1)
t2r(t)

t1 = trotx(.1)
t2 = troty(.2)
trinterp(t1, t2, 0)
trinterp(t1, t2, 1)
trinterp(t1, t2, 0.5)

# predicates
isvec(v1)
isvec(r)
isvec(t)

isrot(v1)
isrot(r)
isrot(t)

ishomog(v1)
ishomog(r)
ishomog(t)
linalg.det(t)

# translational matrices
transl(0.1, 0.2, 0.3)
transl( [0.1, 0.2, 0.3] )
transl( mat([0.1, 0.2, 0.3]) )
t = transl(0.1, 0.2, 0.3)
transl(t)

# angle conversions
eul2r(.1, .2, .3)
eul2r( [.1, .2, .3] )
eul2r( mat([[.1, .2, .3], [.4, .5, .6]]) )
eul2r( mat([.1, .2, .3]) )
eul2tr(.1, .2, .3)
eul2tr( [.1, .2, .3] )
eul2tr( mat([.1, .2, .3]) )
te = eul2tr( mat([.1, .2, .3]) )
tr2eul(te)

rpy2r(.1, .2, .3)
rpy2r( [.1, .2, .3] )
rpy2r( mat([.1, .2, .3]) )
rpy2tr(.1, .2, .3)
rpy2tr( [.1, .2, .3] )
rpy2tr( mat([.1, .2, .3]) )
tr = rpy2tr( mat([.1, .2, .3]) )
tr2rpy(tr)

oa2r(v1, v2)
oa2tr(v1, v2)
t = oa2tr(v1, v2)
trnorm(t)

rotvec2r(0.1, mat([1,2,3]) )

# special matrices
skew(.1, .2, .3)
skew( mat([.1, .2 ,.3]) )
m = skew( mat([.1, .2 ,.3]) )
skew(m)
skew( mat([.1, .2 ,.3, .4, .5, .6]) )
m = skew( mat([.1, .2 ,.3, .4, .5, .6]) )
skew(m)

# quaternions

quaternion(0.1)
quaternion( mat([1,2,3]), 0.1 )
quaternion( rotx(0.1) )
quaternion( trotx(0.1) )
quaternion( quaternion(0.1) )
quaternion( mat([1,2,3,4]) )
quaternion( array([1,2,3,4]) )
quaternion( [1,2,3,4] )
quaternion( 1, 2, 3, 4)
quaternion( 0.1, mat([1,2,3]) )

q1 = quaternion( rotx(0.1) );
q1.norm()
q1.unit()
q1.norm()
q1.double()
q1.r()
q1.tr()

q1 = quaternion( rotx(0.1) );
q2 = quaternion( roty(0.2) );
q1_t = q1
q2_t = q2
q1*2
2*q1
q1**1
q1**2
q1*q1
q1+q2
q1-q2
q1*q2
q2.inv()
q2*q2.inv()
q2*q2**-1
q1/q2
q1*v1
q1*v1.T

q1
q2
q1.interp(q2, 0)
q1.interp(q2, 1)
q1.interp(q2, 0.5)
q1.interp(q2, [0, .2, .5, 1])

q1-q1_t
q2-q2_t
q1
q1 *= q2
q1
q1 *= 2
q1
q2
''';

for line in tests.split('\n'):
    if line == '' or line[0] in '%#':
        continue;
    print '::', line;
    if '=' in line:
        exec line;
    else:
        print eval(line);
    print

