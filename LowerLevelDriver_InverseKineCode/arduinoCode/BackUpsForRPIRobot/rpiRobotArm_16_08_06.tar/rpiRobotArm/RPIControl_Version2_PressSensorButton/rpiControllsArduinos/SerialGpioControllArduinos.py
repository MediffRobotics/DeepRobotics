import RPi.GPIO as GPIO
import time
import serial
import threading
import random
import pandas as pd
import sys
sys.path.append("../rpiDetectPushButtons/")
import RpiButtonDetectors

class rpiControllArduinos(threading.Thread):
        
        def __init__(self,baudrate=9600,PortNum="/dev/ttyACM0"):                                            
                            
                #ENA Pin defination
                self.ArduEna_Base=29
                self.ArduEna_LowArm=31
                self.ArduEna_UpArm=33
                self.ArduEna_Wrist1=35
                self.ArduEna_Wrist2=37
                self.ArduEna_Wrist3=40
              
                GPIO.setmode(GPIO.BOARD)
                
                GPIO.setup(self.ArduEna_Base, GPIO.IN)
                GPIO.setup(self.ArduEna_LowArm, GPIO.IN)
                GPIO.setup(self.ArduEna_UpArm, GPIO.IN)
                GPIO.setup(self.ArduEna_Wrist1, GPIO.IN)
                GPIO.setup(self.ArduEna_Wrist2, GPIO.IN)
                GPIO.setup(self.ArduEna_Wrist3, GPIO.IN)
               
                print "Serial initialization... "
                
                
                self.port=serial.Serial(PortNum,baudrate,timeout=0)
                time.sleep(3)
                self.port.readall() #clear serial buffer
                
                #Init Button class
                self.ButtonStatus=RpiButtonDetectors.RpiRobotArmButtons()
                self.ButtonStatus.setDaemon(True)
                self.ButtonStatus.start()
                # Init threading
                threading.Thread.__init__(self)
                print "done. "
                
                # Init moving data
                self.strMove_a='0a'
                self.strMove_b='0b'
                self.strMove_c='0c'
                self.strMove_d='0d'
                self.strMove_e='0e'
                self.strMove_f='0f'   
                       
                self.ProcessedSerialData=\
                    pd.DataFrame([self.strMove_a,self.strMove_b,self.strMove_c,\
                    self.strMove_d,self.strMove_e,self.strMove_f]).T
                
                self.OnTeachingFlag=0
        
        def DetectBaseENA(self):				
                #print "Base ENA: ",GPIO.input(self.ArduEna_Base)
                return GPIO.input(self.ArduEna_Base)
                
        def DetectUpArmENA(self):				
                #print "DetectUpArmENA: ",GPIO.input(self.ArduEna_Base)
                
                return GPIO.input(self.ArduEna_UpArm)        
                
        def DetectLowArmENA(self):				
                #print "DetectLowArmENA: ",GPIO.input(self.ArduEna_LowArm)
                return GPIO.input(self.Ardu-lEna_LowArm)  
                
        def DetectWrist1ENA(self):				
                #print "DetectWrist1ENA: ",GPIO.input(self.ArduEna_Wrist1)
                return GPIO.input(self.ArduEna_Wrist1)
                
        def DetectWrist2ENA(self):				
                #print "DetectWrist2ENA: ",GPIO.input(self.ArduEna_Wrist2)
                return GPIO.input(self.ArduEna_Wrist2)
                
        def DetectWrist3ENA(self):				
                #print "DetectWrist2ENA: ",GPIO.input(self.ArduEna_Wrist2)
                return GPIO.input(self.ArduEna_Wrist3)                
                
        def DetecAllENA(self):
                if self.DetectBaseENA() == self.DetectUpArmENA()\
                   ==self.DetectLowArmENA() ==self.DetectWrist1ENA()\
                   ==self.DetectWrist2ENA()==self.DetectWrist3ENA()==1:
                       #print "All motors have done"
                       return True                       
                else:
                    #print "At least one motor has not done"
                    return False        
                                                           
        def MoveSteps(self,NumSteps):		
                self.port.write(NumSteps)
                time.sleep(0.01) # wait for a while,to let data receive                
                #while self.DetecAllENA()==0:					
                #    time.sleep(0.02) # wait
                #    print 'wait for done...'
                    
                #print 'Done for one move'
                
        def ProcessingReceived(self,data):                                                                   
                                                                                                
            List_data=data.split(';')
                                 
            #if not pressed button,concate to one row                             
            for i in List_data: 
                #print i            
                if  i.find('a')>-1: #In teaching mode
                    self.strMove_a=self.strMove_a+i
                    print 'append a'
                    
                if  i.find('b')>-1: #In teaching mode
                    self.strMove_b=self.strMove_b+i
                    print 'append b'
                    
                if  i.find('c')>-1: #In teaching mode
                    self.strMove_c=self.strMove_c+i
                    print 'append c'
                    
                if  i.find('d')>-1: #In teaching mode
                    self.strMove_d=self.strMove_d+i
                    print 'append d'
                    
                if  i.find('e')>-1: #In teaching mode
                    self.strMove_e=self.strMove_e+i
                    print 'append e'
                    
                if  i.find('f')>-1: #In teaching mode
                    self.strMove_f=self.strMove_f+i
                    print 'append f'                                                  
                                                                        
        def ProcessingPushButtons(self):
           
            if self.ButtonStatus.FlagPress_TeachingButton==1: #check for teaching flag  
                # start teaching, reset all variables                        
                print "start teaching"
                
                self.strMove_a='0a'
                self.strMove_b='0b'
                self.strMove_c='0c'
                self.strMove_d='0d'
                self.strMove_e='0e'
                self.strMove_f='0f'
                
                self.ProcessedSerialData=self.ProcessedSerialData.append\
                    (pd.DataFrame([self.strMove_a,self.strMove_b,self.strMove_c,\
                    self.strMove_d,self.strMove_e,self.strMove_f]).T)
                    
                self.OnTeachingFlag=1
                               
                                            
                self.ButtonStatus.FlagPress_TeachingButton=0
          
            elif self.ButtonStatus.FlagPress_InsertMovementButton==1: 
                                                
                # append data 
                self.ProcessedSerialData=self.ProcessedSerialData.append\
                    (pd.DataFrame([self.strMove_a,self.strMove_b,self.strMove_c,\
                    self.strMove_d,self.strMove_e,self.strMove_f]).T)  
                           
                # reset passed data,prepare for next move
                self.strMove_a='0a'
                self.strMove_b='0b'
                self.strMove_c='0c'
                self.strMove_d='0d'
                self.strMove_e='0e'
                self.strMove_f='0f'
                                
                #Get received data and processing it  
                print "Inserted a new movement "
                print self.ProcessedSerialData                                                
                    
                self.ButtonStatus.FlagPress_InsertMovementButton=0
                                                                    
            elif self.ButtonStatus.FlagPress_PlayResetButton==1:   
                              
                #if pressed teaching button, saving data,doing reversing                
                if (self.OnTeachingFlag==1):
                    self.SaveMoveData()                
                    
                    self.ButtonStatus.FlagPress_PlayResetButton=0
                    self.OnTeachingFlag==0
                
                #else, loading data, send data and move command to controllers
                else:   
                    print "Presed play/Reset button"                                
                    self.ProcessedSerialData=pd.read_csv('MoveData.csv')                                                                          
                    self.ButtonStatus.FlagPress_PlayResetButton=0                                                                                                    
                    #ProcessedSerialData.iat[1,1] access data
                    
                    
        def SaveMoveData(self):    
            
            self.ProcessedSerialData.to_csv('MoveData.csv',index=False)
            print "all data is saved"
            
            
            
        def run(self):
            while 1:
                #Processing received data
                
                Data=self.port.readall()
                if Data!='':
                    self.ProcessingReceived(Data) 
                    #print self.serialData
                
                time.sleep(0.3) 
                
                #Processing push buttons
                self.ProcessingPushButtons();                          
            
        def CloseSerial(self):
                self.port.close()

if __name__=='__main__':
                          
        ############################
        SerialSendToArduino=rpiControllArduinos()            
        SerialSendToArduino.setDaemon(True)
        SerialSendToArduino.start()
        time.sleep(5)
        
        print 'sending data'
        

      
